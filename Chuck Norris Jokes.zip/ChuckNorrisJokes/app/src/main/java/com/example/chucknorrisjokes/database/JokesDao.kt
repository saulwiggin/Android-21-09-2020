package com.example.chucknorrisjokes.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.chucknorrisjokes.utils.Converters

@Dao
interface JokesDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(jokes : List<DatabaseJokes>)

    @Query("SELECT * FROM DatabaseJokes")
    fun getLocalDBJokes(): LiveData<List<DatabaseJokes>>
}

@Database(entities = arrayOf(DatabaseJokes::class), version = 1)
@TypeConverters(Converters::class)
abstract class JokesDatabase: RoomDatabase(){
    abstract val jokesDao: JokesDao
}