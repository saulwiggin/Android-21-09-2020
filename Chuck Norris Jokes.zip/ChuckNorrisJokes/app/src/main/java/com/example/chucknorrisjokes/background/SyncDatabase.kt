package com.example.chucknorrisjokes.background

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.chucknorrisjokes.repository.JokesRepository
import org.koin.core.KoinComponent
import org.koin.core.inject
import java.lang.Exception

class SyncDatabase(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext, params),
    KoinComponent
    {
        val jokesRepository : JokesRepository by inject()

        companion object{
            const val WORK_NAME = "com.example.chucknorrisjokes.background.SyncDatabase"
        }

        override suspend fun doWork(): Result {
            try {
                jokesRepository.refreshJokes()
            }catch (e: Exception){
                return Result.retry()
            }
            return Result.success()
        }
    }