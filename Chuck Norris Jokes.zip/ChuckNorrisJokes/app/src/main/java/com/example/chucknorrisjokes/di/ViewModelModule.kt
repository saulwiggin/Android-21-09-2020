package com.example.chucknorrisjokes.di

import com.example.chucknorrisjokes.viewmodel.JokesListViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule= module {
    viewModel { JokesListViewModel(get()) }
}