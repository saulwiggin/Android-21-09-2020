package com.example.chucknorrisjokes.ui.main

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.chucknorrisjokes.R
import com.example.chucknorrisjokes.recycler_adapter.JokesAdapter
import com.example.chucknorrisjokes.databinding.MainFragmentBinding
import com.example.chucknorrisjokes.viewmodel.JokesListViewModel
import org.koin.android.viewmodel.compat.ViewModelCompat.viewModel
import org.koin.android.viewmodel.ext.android.viewModel

class MainFragment : Fragment() {

    private var viewModelAdapter: JokesAdapter? = null
    private lateinit var v: View

    companion object {
        fun newInstance() = MainFragment()
    }

    private val viewModel:JokesListViewModel by viewModel()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        val binding: MainFragmentBinding =
            DataBindingUtil.inflate(inflater, R.layout.main_fragment, container, false)
        v = binding.root.findViewById(R.id.JokesList_Fragment_Layout)
        binding.setLifecycleOwner(viewLifecycleOwner)
        binding.viewmodel = viewModel

        binding.root.findViewById<RecyclerView>(R.id.recycler_view).apply {
            layoutManager = GridLayoutManager(context, 2)
            adapter = viewModelAdapter
        }

        setHasOptionsMenu(true);

        return binding.root

    }

}