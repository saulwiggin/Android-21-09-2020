package com.example.chucknorrisjokes.network

object API_Calls {
    const val API_BASE_URL = "http://api.icndb.com/"
    const val JOKES_LIST = "jokes/jokenumber"
}