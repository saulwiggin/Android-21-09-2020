package com.example.chucknorrisjokes.di

import android.app.Application
import androidx.room.Room
import com.example.chucknorrisjokes.database.JokesDatabase
import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

val databaseModule = module {
    fun providersDatabase(application: Application): JokesDatabase{
        return Room.databaseBuilder(application, JokesDatabase::class.java, "breaking.database")
            .fallbackToDestructiveMigration()
            .allowMainThreadQueries()
            .build()
    }

    single { providersDatabase(androidApplication())
    }
}