package com.example.chucknorrisjokes.di

import com.example.chucknorrisjokes.network.ChuckNorrisJokes_API
import org.koin.dsl.module
import retrofit2.Retrofit

val apiModule = module {
    fun provideUserApi(retrofit: Retrofit): ChuckNorrisJokes_API{
        return retrofit.create(ChuckNorrisJokes_API::class.java)
    }

    single { provideUserApi(get()) }
}