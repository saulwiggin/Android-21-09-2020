package com.example.chucknorrisjokes.di

import com.example.chucknorrisjokes.database.JokesDatabase
import com.example.chucknorrisjokes.network.ChuckNorrisJokes_API
import com.example.chucknorrisjokes.repository.JokesRepository
import org.koin.dsl.module

val repositoryModule= module {
    fun provideRepository(api: ChuckNorrisJokes_API, dao: JokesDatabase):JokesRepository{
        return JokesRepository(api, dao)
    }

    single { provideRepository(get(), get())
    }
}