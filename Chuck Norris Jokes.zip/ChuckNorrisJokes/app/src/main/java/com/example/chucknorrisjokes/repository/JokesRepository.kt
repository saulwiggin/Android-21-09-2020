package com.example.chucknorrisjokes.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataScope
import com.example.chucknorrisjokes.database.DatabaseJokes
import com.example.chucknorrisjokes.database.JokesDatabase
import com.example.chucknorrisjokes.network.ChuckNorrisJokes_API
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber

class JokesRepository
    (private val ChuckNorrisJokes_API: ChuckNorrisJokes_API,
     private val database: JokesDatabase
)
{
    suspend fun refreshJokes(){
        withContext(Dispatchers.IO){
            Timber.d("refresh jokes is called");
            val JokesList = ChuckNorrisJokes_API.getJokes().await()
            database.jokesDao.insertAll(JokesList)
        }
    }

    val results: LiveData<List<DatabaseJokes>> = database.jokesDao.getLocalDBJokes()
}