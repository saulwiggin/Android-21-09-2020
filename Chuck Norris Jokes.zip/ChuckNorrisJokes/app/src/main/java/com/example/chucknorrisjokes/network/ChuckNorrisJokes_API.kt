package com.example.chucknorrisjokes.network

import retrofit2.http.GET
import kotlinx.coroutines.Deferred
import com.example.chucknorrisjokes.database.DatabaseJokes

interface ChuckNorrisJokes_API {
    @GET(API_Calls.JOKES_LIST)
    fun getJokes(): Deferred<List<DatabaseJokes>>
}