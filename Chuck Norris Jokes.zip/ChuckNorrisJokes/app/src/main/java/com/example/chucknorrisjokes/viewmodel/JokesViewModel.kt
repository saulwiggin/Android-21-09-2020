package com.example.chucknorrisjokes.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.chucknorrisjokes.database.JokesDatabase
import com.example.chucknorrisjokes.repository.JokesRepository
import kotlinx.coroutines.*
import java.lang.Exception

class JokesListViewModel (private val jokesRepository: JokesRepository): ViewModel(){
    private val viewModelJob = SupervisorJob()
    private val viewModelScope  = CoroutineScope(viewModelJob + Dispatchers.Main)

    val jokeListResults = jokesRepository.results

    init {
        refreshFromRepository()
    }

    fun refreshFromRepository(){
        viewModelScope.launch {
            try {
                jokesRepository.refreshJokes()
            }
            catch(networkError: Exception){

            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.cancel()
    }
}