To do:

add login

add payments

add transactions

add bitcoin

add dashboard for ''droogcoin''

smart contracts and etherium and all that interesting stuff