package com.example.paywithbitcoin.network

object API {
    const val API_BASE_URL="https://api.coindesk.com/"
    const val CURRENT_PRICE_API="v1/bpi/currentprice.json"

}