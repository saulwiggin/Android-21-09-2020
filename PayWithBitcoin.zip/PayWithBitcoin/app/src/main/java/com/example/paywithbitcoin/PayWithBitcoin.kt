package com.example.paywithbitcoin

import android.app.Application
import com.example.paywithbitcoin.di.databaseModule
import com.example.paywithbitcoin.di.netModule
import com.example.paywithbitcoin.di.repositoryModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class PayWithBitcoin: Application(){

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@PayWithBitcoinn)
            modules(viewModelModule, repositoryModule, netModule, apiModule, databaseModule)
        }
    }
}