package com.example.paywithbitcoin.ui.dashboard

data class Currency(
    val title: String,
    var isChecked: Boolean
)