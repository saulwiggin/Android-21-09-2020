package com.example.paywithbitcoin.network

object Coinlore {
    const val API_BASE_COINLORE ="https://api.coinlore.net/api/ticker/"
    const val BTC ="?id=90"
}