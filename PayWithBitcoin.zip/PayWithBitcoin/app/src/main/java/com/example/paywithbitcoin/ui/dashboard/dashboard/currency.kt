package com.example.paywithbitcoin.ui.dashboard.dashboard

data class Currency(
    val title: String,
    var isChecked: Boolean
)