package com.example.paywithbitcoin.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey

@Entity(tableName = "DatabaseBitcoin")
data class DatabaseBitcoin (
    @PrimaryKey
    @ColumnInfo(name="id") var id: Int,
    @Ignore var time: Time,
    @ColumnInfo(name="disclaimer") var disclaimer: String,
    @ColumnInfo(name="chartname")  var chartname: String,
    @Ignore var bpi: List<Currency>
)

@Entity(tableName = "Time")
data class Time(
    @PrimaryKey
    @ColumnInfo(name="updated") var updated: String,
    @ColumnInfo(name="updatedISO") var updatedISO:String,
    @ColumnInfo(name="updateduk") var updateduk: String,
)

data class Currency (
    @PrimaryKey
    @ColumnInfo(name="id") var id: Int,
    @ColumnInfo(name="code") var code: String?,
    @ColumnInfo(name="symbol") var symbol: String?,
    @ColumnInfo(name="rate") var rate: String?,
    @ColumnInfo(name="description") var description: String,
    @ColumnInfo(name="rate_float")var rate_float: String
)
