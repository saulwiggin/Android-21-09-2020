package com.example.paywithbitcoin.network

object Binance {
    const val BASE_URL = "https://api.binance.com"
    const val LATEST_TRADES ="GET /api/v3/trades"
}