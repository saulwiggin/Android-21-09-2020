package com.example.paywithbitcoin.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.paywithbitcoin.dto.Bitcoin
import com.example.paywithbitcoin.database.DatabaseBitcoin

@Dao
interface BitcoinDAO {

    @Query("SELECT * FROM DatabaseBitcoin")
    fun getLocalDBJokes(): LiveData<List<DatabaseBitcoin>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(prices: DatabaseBitcoin)

}

@Database(entities = [DatabaseBitcoin::class], version  = 1, exportSchema = true)
abstract class BitcoinDatabase: RoomDatabase(){
    abstract val bitcoinDao: BitcoinDAO
}