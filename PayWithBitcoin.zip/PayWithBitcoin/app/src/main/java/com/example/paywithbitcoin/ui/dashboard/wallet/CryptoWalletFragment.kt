package com.example.paywithbitcoin.ui.dashboard.wallet

import androidx.fragment.app.Fragment

class CryptoWalletFragment: Fragment() {
    @Override
    fun onCreate(){

    }

    @Override
    fun onCreateView(){

    }

}