package com.androiddevs.mvvmnewsapp.ui.fragments

import androidx.fragment.app.Fragment
import com.androiddevs.mvvmnewsapp.R

class ArticleNewsFragment : Fragment(R.layout.fragment_article) {
}