package com.androiddevs.mvvmnewsapp.ui.fragments

import androidx.fragment.app.Fragment
import com.androiddevs.mvvmnewsapp.R

class BreakingNewsFragment : Fragment(R.layout.fragment_breaking_news) {
}