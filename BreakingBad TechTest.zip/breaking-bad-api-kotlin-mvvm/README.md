# breaking-bad-app-mvvm
Android app in kotlin and MVVM developed using the breaking bad api

developed in kotlin and mvvm

the idea of the app is to use the breaking bad api, the search filter also allows you to search through the recyclerview and filter the results

clicking on the character reveals their own fragment which tells you further details


app home
![alt text](https://github.com/gaffycool/breaking-bad-api-kotlin-mvvm/blob/master/screenshots/app%20home.png)

scrolling down the recyclerview 
![alt text](https://github.com/gaffycool/breaking-bad-api-kotlin-mvvm/blob/master/screenshots/scrolling%20down%20list.png)

filter using seasons drop down
![alt text](https://github.com/gaffycool/breaking-bad-api-kotlin-mvvm/blob/master/screenshots/filter%20using%20seasons.png)

search filter
![alt text](https://github.com/gaffycool/breaking-bad-api-kotlin-mvvm/blob/master/screenshots/search%20filter.png)

character details
![alt text](https://github.com/gaffycool/breaking-bad-api-kotlin-mvvm/blob/master/screenshots/character%20description.png)
