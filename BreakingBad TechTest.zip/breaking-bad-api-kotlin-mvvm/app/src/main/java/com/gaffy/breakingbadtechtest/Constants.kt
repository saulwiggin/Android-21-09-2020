package com.gaffy.breakingbadtechtest

const val BASE_URL = "https://breakingbadapi.com"
const val API_CHARACTERS = "/api/characters"