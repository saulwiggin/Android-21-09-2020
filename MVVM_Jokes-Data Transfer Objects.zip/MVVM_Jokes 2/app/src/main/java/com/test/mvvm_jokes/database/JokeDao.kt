package com.test.mvvm_jokes.database

import androidx.lifecycle.LiveData
import androidx.room.*


@Dao
interface JokeDao {

    @Query("SELECT * FROM DatabaseJoke")
    fun getLocalDBJokes(): LiveData<List<DatabaseJoke>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(joke: List<DatabaseJoke>)

}

@Database(entities = [DatabaseJoke::class], version = 1, exportSchema = false)
//@TypeConverters(Converters::class)
abstract class JokeDatabase : RoomDatabase() {
    abstract val jokeDao: JokeDao
}