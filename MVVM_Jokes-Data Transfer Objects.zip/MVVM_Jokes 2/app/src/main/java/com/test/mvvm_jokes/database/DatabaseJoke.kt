package com.test.mvvm_jokes.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.test.mvvm_jokes.domain.Joke


@Entity
data class DatabaseJoke(
    @PrimaryKey
    var id: Int,
    var joke: String
)
fun List<DatabaseJoke>.asDomainModel():List<Joke> {
    return map {
        Joke(
            id = it.id,
            joke = it.joke
        )
    }
}
