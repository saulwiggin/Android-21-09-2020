package com.test.mvvm_jokes.network

object API_Calls {
    const val API_BASE_URL= "http://api.icndb.com/"
    const val API_JOKE_LIST= "jokes/jokenumber"
}