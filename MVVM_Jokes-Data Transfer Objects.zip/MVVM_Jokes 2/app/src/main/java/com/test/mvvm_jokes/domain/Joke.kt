package com.test.mvvm_jokes.domain

data class Joke(
        var id: Int,
        var joke: String
)