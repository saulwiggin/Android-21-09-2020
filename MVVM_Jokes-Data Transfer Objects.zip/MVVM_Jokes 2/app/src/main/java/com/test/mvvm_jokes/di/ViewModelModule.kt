package com.test.mvvm_jokes.di

import com.test.mvvm_jokes.viewmodel.JokeViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule= module {
    viewModel { JokeViewModel(get()) }
}