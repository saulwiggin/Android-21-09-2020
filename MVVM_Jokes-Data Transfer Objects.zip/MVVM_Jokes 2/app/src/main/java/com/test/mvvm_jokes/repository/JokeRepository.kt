package com.test.mvvm_jokes.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.test.mvvm_jokes.database.JokeDatabase
import com.test.mvvm_jokes.database.asDomainModel
import com.test.mvvm_jokes.domain.Joke
import com.test.mvvm_jokes.network.Jokes_APIServices
import com.test.mvvm_jokes.network.asDatabaseModel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber

class JokeRepository(private val jokesApiservices: Jokes_APIServices, private val database: JokeDatabase) {
    suspend fun refreshJokes() {
        // worker thread to perform API request and saving data locally
        withContext(Dispatchers.IO) {
            Timber.d("Refresh joke is called")
            val jokeList = jokesApiservices.getJoke().await()
            database.jokeDao.insertAll(jokeList.asDatabaseModel())
        }
    }

    val results: LiveData<List<Joke>> = Transformations.map(database.jokeDao.getLocalDBJokes()){
        it.asDomainModel()
    }

}