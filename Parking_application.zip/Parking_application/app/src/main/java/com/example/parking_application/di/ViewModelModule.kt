package com.example.parking_application.di

import com.example.parking_application.viewmodel.MapsViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule= module {
    viewModel { MapsViewModel(get()) }
}