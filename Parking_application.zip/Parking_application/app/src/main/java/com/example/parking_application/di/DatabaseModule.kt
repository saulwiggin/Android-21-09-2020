package com.example.parking_application.di

import android.app.Application
import androidx.room.Room
import com.example.parking_application.database.LocationDatabase
import org.koin.android.ext.koin.androidApplication
import org.koin.dsl.module

val databaseModule = module {
    fun providesDatabase(application: Application): LocationDatabase {
        return Room.databaseBuilder(application, LocationDatabase::class.java, "Maps.database")
            .fallbackToDestructiveMigration()
            .allowMainThreadQueries()
            .build()
    }

    single { providesDatabase(androidApplication())}
}