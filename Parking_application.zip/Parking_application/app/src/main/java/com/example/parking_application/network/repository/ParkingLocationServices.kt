package com.example.parking_application.network.repository

import com.example.parking_application.database.Location
import kotlinx.coroutines.Deferred
import retrofit2.http.GET

interface ParkingLocationServices {
    @GET(API.PARKING_URL)
    fun getParkingLocations(): Deferred<List<Location>>
}