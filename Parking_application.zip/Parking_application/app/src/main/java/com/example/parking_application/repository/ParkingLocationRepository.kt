package com.example.parking_application.repository

import android.util.Log
import com.example.parking_application.database.Location
import com.example.parking_application.database.LocationDatabase
import com.example.parking_application.network.repository.ParkingLocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ParkingLocationRepository(private val parkingLocationsServices: ParkingLocationServices, private val database: LocationDatabase) {

    val TAG = "API CALL"

    suspend fun getLocations(){
        withContext(Dispatchers.IO){
            val parkinglocations = parkingLocationsServices.getParkingLocations().await()
            Log.v(TAG,parkinglocations.toString())
            database.locationDao.insertAll(parkinglocations)
        }
    }

    val results: List<Location> = database.locationDao.getLocalDBLocations()

}