package com.example.parking_application.network.repository

object API {
    const val API_BASE_URL="https://ridecellparking.herokuapp.com/api/v1/"
    const val PARKING_URL="parkinglocations?format=json"
}