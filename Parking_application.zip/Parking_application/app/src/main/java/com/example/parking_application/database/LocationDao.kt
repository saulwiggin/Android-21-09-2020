package com.example.parking_application.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.*

@Dao
interface LocationDao {
    @Query("SELECT * FROM Location")
    fun getLocalDBLocations(): List<Location>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(locations: List<Location>)
}

@Database(entities = [Location::class], version = 1, exportSchema = false)
abstract class LocationDatabase: RoomDatabase() {
    abstract val locationDao: LocationDao
}