package com.example.parking_application.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.*

@Dao
interface LocationDao {
    @Query("SELECT * FROM Location")
    fun getLocalDBLocations(): LiveData<List<Location>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(locations: LiveData<List<Location>>)
}

@Database(entities = [Location::class], version = 2, exportSchema = false)
abstract class LocationDatabase: RoomDatabase() {
    abstract val locationDao: LocationDao
}