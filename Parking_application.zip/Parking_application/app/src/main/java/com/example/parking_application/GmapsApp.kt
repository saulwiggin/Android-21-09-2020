package com.example.parking_application

import android.app.Application
import com.example.parking_application.di.*
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level

class GmapsApp: Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@GmapsApp)
            androidLogger(Level.NONE)
            modules(listOf(viewModelModule, repositoryModule, netModule, apiModule, databaseModule))
        }
    }
}