package com.example.parking_application.di

import com.example.parking_application.database.LocationDatabase
import com.example.parking_application.network.repository.ParkingLocationServices
import com.example.parking_application.repository.ParkingLocationRepository
import org.koin.dsl.module

val repositoryModule = module {
    fun provideRepository(api: ParkingLocationServices, dao: LocationDatabase): ParkingLocationRepository{
        return ParkingLocationRepository(api, dao)
    }

    single {
        provideRepository(get(), get())
    }
}