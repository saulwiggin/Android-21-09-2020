package com.example.parking_application.viewmodel

import androidx.lifecycle.ViewModel
import com.example.parking_application.repository.ParkingLocationRepository
import kotlinx.coroutines.*

class MapsViewModel(private val parkingRepository: ParkingLocationRepository): ViewModel() {

    // Get Parking Locations

    val Job = SupervisorJob()
    val Scope = CoroutineScope(Job + Dispatchers.Main)

    val parkingResults = parkingRepository.results

    init {
        getLocationResults()
    }

    fun getLocationResults(){
        Scope.launch {
            try {
                 parkingRepository.getLocations()
            } catch(networkError: Exception){

            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        Scope.cancel()
    }
}