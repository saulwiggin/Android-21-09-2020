package com.example.parking_application.di

import com.example.parking_application.network.repository.ParkingLocationServices
import org.koin.dsl.module
import retrofit2.Retrofit

val apiModule = module {
    fun provideApi(retrofit: Retrofit): ParkingLocationServices {
        return retrofit.create(ParkingLocationServices::class.java)
    }

    single { provideApi(get())}
}