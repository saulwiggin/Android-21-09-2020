package com.example.parking_application.model

data class latlng (
    val lat: String,
    val lng: String
)