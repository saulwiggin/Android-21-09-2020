package com.example.parking_application.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Location (
    @PrimaryKey
    @ColumnInfo(name="id") val id: Int,
    @ColumnInfo(name="lat") val lat: String,
    @ColumnInfo(name="lng") val lng: String,
    @ColumnInfo(name="name") val name: String,
    @ColumnInfo(name="cost_per_minue") val cost_per_minue: String,
    @ColumnInfo(name="max_reserve_time_mins") val max_reserve_time_mins: Int,
    @ColumnInfo(name="min_reserve_time_mins") val min_reserve_time_mins: Int,
    @ColumnInfo(name="is_reserved" )val is_reserved: Boolean,
    @ColumnInfo(name="reserved_until") val reserved_until: String
)