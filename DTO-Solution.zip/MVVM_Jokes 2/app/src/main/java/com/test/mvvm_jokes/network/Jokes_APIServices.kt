package com.test.mvvm_jokes.network


import kotlinx.coroutines.Deferred
import retrofit2.http.GET

interface Jokes_APIServices {
    @GET(API_Calls.API_JOKE_LIST)
    fun getJoke(): Deferred<NetworkJokeContainer>
}