package com.test.mvvm_jokes.network


import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.test.mvvm_jokes.database.DatabaseJoke

@JsonClass(generateAdapter = true)
data class NetworkJokeContainer(val value: List<ValueItem>)


data class ValueItem(

	@Json(name="id") val id: Int,

	@Json(name="joke") val joke: String
)

fun NetworkJokeContainer.asDatabaseModel() : List<DatabaseJoke> {
	return value.map {
		DatabaseJoke(
			id = it.id,
			joke = it.joke
		)
	}
}

