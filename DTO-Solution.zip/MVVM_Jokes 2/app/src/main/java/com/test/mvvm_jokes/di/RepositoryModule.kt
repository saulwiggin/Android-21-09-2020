package com.test.mvvm_jokes.di


import com.test.mvvm_jokes.database.JokeDatabase
import com.test.mvvm_jokes.network.Jokes_APIServices
import com.test.mvvm_jokes.repository.JokeRepository
import org.koin.dsl.module

val repositoryModule = module {
    fun provideRepository(api: Jokes_APIServices, dao: JokeDatabase): JokeRepository {
        return JokeRepository(api, dao)
    }

    single {
        provideRepository(get(), get())
    }
}