package com.example.cakesapimvvm

import org.koin.test.KoinTest

class FeaturePresenterTest : KoinTest {

  
}