package com.example.cakesapimvvm.network

object API_Calls {
    const val API_BASE_URL="https://gist.githubusercontent.com/hart88/"
    const val CAKES_LIST_API = "98f29ec5114a3ec3460/raw/8dd19a88f9b8d24c23d9960f3300d0c917a4f07c/cake.json"
}