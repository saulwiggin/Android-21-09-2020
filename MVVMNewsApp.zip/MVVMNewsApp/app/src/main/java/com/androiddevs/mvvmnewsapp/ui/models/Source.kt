package com.androiddevs.mvvmnewsapp.ui.models

data class Source(
    val id: Any,
    val name: String
)