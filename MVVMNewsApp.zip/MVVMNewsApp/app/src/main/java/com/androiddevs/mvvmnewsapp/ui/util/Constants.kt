package com.androiddevs.mvvmnewsapp.ui.util

class Constants {
    companion object {
        const val API_KEY = "d3cc3f924369419989fbfe463e92c07a"
        const val BASE_URL = "https://newsapi.org"
    }
}